##  Slashing Protection Database Interchange

A format has been standardised to allow different clients to export and import slashing protection data.
[Slashing Protection Database Interchange](https://hackmd.io/@sproul/Bk0Y0qdGD)

Teku stores enough data to generate the minimal specification, so only the minimal export can be accomplished, 
but loading of the complete specification is supported.
